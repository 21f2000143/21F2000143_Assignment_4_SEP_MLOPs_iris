# This is an example feature definition file

from datetime import timedelta
from datetime import timedelta

from feast import BigQuerySource, Entity, Feature, FeatureView, ValueType, Project, Field
from datetime import timedelta
from feast import Entity, FeatureView, Field, FileSource, FeatureStore
from feast.data_format import FileFormat
from feast.types import Float32, Int64

# Define a project for the feature repo
project = Project(name="iris_feast", description="A project for driver statistics")

# Define an entity for the driver. You can think of an entity as a primary key used to
# fetch features.
iris = Entity(name="iris_id", join_keys=["iris_id"], value_type=ValueType.INT64)

# Read data from parquet files. Parquet is convenient for local development mode. For
# production, you can use your favorite DWH, such as BigQuery. See Feast documentation
# for more info.
iris_stats_source = BigQuerySource(
    table="21f2000143_mlops_week3_ga_3_feast.iris_hourly_stats",
    timestamp_field="event_timestamp",
)
# Our parquet files contain sample data that includes a driver_id column, timestamps and
# three feature column. Here we define a Feature View that will allow us to serve this
# data to our model online.
iris_stats_fv = FeatureView(
    # The unique name of this feature view. Two feature views in a single
    # project cannot have the same name
    name="iris_stats_source",
    entities=[iris],
    # The list of features defined below act as a schema to both define features
    # for both materialization of features into a store, and are used as references
    # during retrieval for building a training dataset or serving features
    ttl=timedelta(weeks=52),
    schema=[
        Field(name="sepal_length", dtype=Float32),
        Field(name="sepal_width", dtype=Float32),
        Field(name="petal_length", dtype=Float32),
        Field(name="petal_width", dtype=Float32),         
    ],
    # Tags are user defined key/value pairs that are attached to each
    # feature view
    source=iris_stats_source,
    tags={"team": "iris_performance"},
)
# driver_stats_fv = FeatureView(

#     name="driver_hourly_stats",
#     entities=[driver],
#     ttl=timedelta(days=1),

#     schema=[
#         Field(name="conv_rate", dtype=Float32),
#         Field(name="acc_rate", dtype=Float32),
#         Field(name="avg_daily_trips", dtype=Int64, description="Average daily trips"),
#     ],
#     online=True,
#     source=driver_stats_source,

#     tags={"team": "driver_performance"},
# )

# # Define a request data source which encodes features / information only
# # available at request time (e.g. part of the user initiated HTTP request)
# input_request = RequestSource(
#     name="vals_to_add",
#     schema=[
#         Field(name="val_to_add", dtype=Int64),
#         Field(name="val_to_add_2", dtype=Int64),
#     ],
# )


# # Define an on demand feature view which can generate new features based on
# # existing feature views and RequestSource features
# @on_demand_feature_view(
#     sources=[driver_stats_fv, input_request],
#     schema=[
#         Field(name="conv_rate_plus_val1", dtype=Float64),
#         Field(name="conv_rate_plus_val2", dtype=Float64),
#     ],
# )
# def transformed_conv_rate(inputs: pd.DataFrame) -> pd.DataFrame:
#     df = pd.DataFrame()
#     df["conv_rate_plus_val1"] = inputs["conv_rate"] + inputs["val_to_add"]
#     df["conv_rate_plus_val2"] = inputs["conv_rate"] + inputs["val_to_add_2"]
#     return df


# # This groups features into a model version
# driver_activity_v1 = FeatureService(
#     name="driver_activity_v1",
#     features=[
#         driver_stats_fv[["conv_rate"]],  # Sub-selects a feature from a feature view
#         transformed_conv_rate,  # Selects all features from the feature view
#     ],
#     logging_config=LoggingConfig(
#         destination=FileLoggingDestination(path="data")
#     ),
# )
# driver_activity_v2 = FeatureService(
#     name="driver_activity_v2", features=[driver_stats_fv, transformed_conv_rate]
# )

# # Defines a way to push data (to be available offline, online or both) into Feast.
# driver_stats_push_source = PushSource(
#     name="driver_stats_push_source",
#     batch_source=driver_stats_source,
# )

# # Defines a slightly modified version of the feature view from above, where the source
# # has been changed to the push source. This allows fresh features to be directly pushed
# # to the online store for this feature view.
# driver_stats_fresh_fv = FeatureView(
#     name="driver_hourly_stats_fresh",
#     entities=[driver],
#     ttl=timedelta(days=1),
#     schema=[
#         Field(name="conv_rate", dtype=Float32),
#         Field(name="acc_rate", dtype=Float32),
#         Field(name="avg_daily_trips", dtype=Int64),
#     ],
#     online=True,
#     source=driver_stats_push_source,  # Changed from above
#     tags={"team": "driver_performance"},
# )


# # Define an on demand feature view which can generate new features based on
# # existing feature views and RequestSource features
# @on_demand_feature_view(
#     sources=[driver_stats_fresh_fv, input_request],  # relies on fresh version of FV
#     schema=[
#         Field(name="conv_rate_plus_val1", dtype=Float64),
#         Field(name="conv_rate_plus_val2", dtype=Float64),
#     ],
# )
# def transformed_conv_rate_fresh(inputs: pd.DataFrame) -> pd.DataFrame:
#     df = pd.DataFrame()
#     df["conv_rate_plus_val1"] = inputs["conv_rate"] + inputs["val_to_add"]
#     df["conv_rate_plus_val2"] = inputs["conv_rate"] + inputs["val_to_add_2"]
#     return df


# driver_activity_v3 = FeatureService(
#     name="driver_activity_v3",
#     features=[driver_stats_fresh_fv, transformed_conv_rate_fresh],
# )




