PROJECT_ID= "ivory-totem-474120-s5" #@param {type:"string"}
BUCKET_NAME= "21f2000143-mlops-week3-ga-3-feast" #@param {type:"string"} custom
BIGQUERY_DATASET_NAME="21f2000143_mlops_week3_ga_3_feast" #@param {type:"string"} custom
AI_PLATFORM_MODEL_NAME="21f2000143-mlops-week3-ga-3-feast" #@param {type:"string"